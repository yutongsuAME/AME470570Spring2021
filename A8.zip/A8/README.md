# Simple image upload app

## Usage

1. Edit `server.js` to add the right mongoURL and bucket name.
2. Edit `public/script.js` to add the right bucketURL.
3. Make sure you have the right `credentials.json` (delete `.gitignore`).
4. `node server.js`
5. Goto http://localhost:8080
